package common;

import org.openqa.selenium.WebDriver;

public class Constant {
    public static WebDriver WEBDRIVER;
    public static final String RAILWAY_URL = "http://railwayb1.somee.com/Page/HomePage.cshtml";

    public static final String USERNAME01_Active = "thuyduyen01@gmail.com";
    public static final String PASSWORD01 = "thuyduyen01";

    public static final String USERNAMETC2 = "";
    public static final String PASSWORDTC2 = "thuyduyen01";

    public static final String USERNAMETC3_Deactive = "quangnguyen17930@gmail.com";
    public static final String PASSWORDTC3 = "kiemthu123abcd";

    public static final String USERNAME02 = "thuyduyen02@gmail.com";
    public static final String PASSWORD02 = "thuyduyen02";

    public static final String USERNAMETC7 = "abc000ghgQuang@gmail.com";
    public static final String PASSWORDTC7 = "kiemthu123abcdefgh";
    public static final String IPTC7 = "12345678";

    public static final String NEWPASSWORDTC97 = "kiemthu123abcdefgh";

    public static final String USERNAMETC10 = "abc000ghgQuangggg@gmail.com";
    public static final String PASSWORDTC10 = "kiemthu123abcdefgh";
    public static final String IPTC10 = "12345678";

    public static final String USERNAMETC11 = "abc000ghgQuanggggggggg@gmail.com";
    public static final String PASSWORDTC11 = "";
    public static final String IPTC11 = "";
}