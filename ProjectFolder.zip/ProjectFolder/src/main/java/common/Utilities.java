package common;

public class Utilities {
    public static String getProjectPath() {
        return "path của project là đây";
    }
}
