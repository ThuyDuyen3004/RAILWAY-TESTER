package pageObjects.Railway;

import common.Constant;
import org.openqa.selenium.*;

import java.util.List;

import static java.lang.Thread.sleep;

public class MyTicketPage extends GeneralPage {
    private final By cancelBtn = By.xpath("//tbody/tr[2]/td[11]/input");

    protected WebElement getCancelBtn() {
        return Constant.WEBDRIVER.findElement(cancelBtn);
    }

    public void clickCancelBtn() {
        WebElement bookButton = getCancelBtn();
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript("arguments[0].scrollIntoView(true);", bookButton);
        sleep(2000);
        getCancelBtn().click();
        sleep(2000);
        Alert alert = Constant.WEBDRIVER.switchTo().alert();
        alert.accept();
    }

    public boolean isTicketCanceledDisplayed() {
        sleep(2000);
        List<WebElement> checkButtonCancel = Constant.WEBDRIVER.findElements(cancelBtn);
        System.out.println("Kiểm tra button Cancel: " + checkButtonCancel.size());
        return checkButtonCancel.size() > 0;  //Nếu có tồn tại thì > 0
        //Mục đích mình là kiểm tra nó sẽ không còn tồn tại, nên nó phải =0, mà thực tế nó vẫn >0 nên SAI
    }
}
