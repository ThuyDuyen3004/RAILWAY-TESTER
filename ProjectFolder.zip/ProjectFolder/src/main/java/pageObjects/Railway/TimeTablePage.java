package pageObjects.Railway;

import common.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import static java.lang.Thread.sleep;

public class TimeTablePage extends GeneralPage {
    //Chọn row Huế to Sài Gòn (dòng 17)
    private final By BookTicketBtn = By.xpath("//td[normalize-space()='17']/following-sibling::td[normalize-space()='book ticket']");

    protected WebElement getBookTicketBtn() {
        return Constant.WEBDRIVER.findElement(BookTicketBtn);
    }

    public BookTicketPage ChoseTicket() {
        sleep(1000);
        Constant.WEBDRIVER.navigate().refresh();
        sleep(1000);
        Constant.WEBDRIVER.navigate().refresh();
        sleep(2000);
        WebElement bookButton = getBookTicketBtn();
        ((JavascriptExecutor) Constant.WEBDRIVER).executeScript("arguments[0].scrollIntoView(true);", bookButton);
        sleep(2000);
        getBookTicketBtn().click();
        sleep(2000);
        return new BookTicketPage();
    }
}
