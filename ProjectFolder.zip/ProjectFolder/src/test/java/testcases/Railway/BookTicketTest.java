package testcases.Railway;

import common.Constant;
import common.Utilities;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pageObjects.Railway.BookTicketPage;
import pageObjects.Railway.HomePage;
import pageObjects.Railway.LoginPage;

public class BookTicketTest extends BaseTest {
    @Test
    public void TC14() {
        System.out.println("TC14 - User can book 1 ticket at a time");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login(Constant.USERNAMETC7, Constant.PASSWORDTC7);
        BookTicketPage bookTicketPage = homePage.gotoBookTicketPage();
        bookTicketPage.BookTicket("5", "3", "3", "1");
        Assert.assertEquals(bookTicketPage.getBookMsg(), "Ticket booked successfully!", "Message \"Ticket booked successfully!\" displays.");
    }
}
