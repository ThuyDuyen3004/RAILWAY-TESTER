package testcases.Railway;

import common.Constant;
import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.Railway.ForgotPassWordPage;
import pageObjects.Railway.HomePage;

public class ForgotPassWordTest extends BaseTest {
    @Test
    public void TC12() {
        System.out.println("TC12 - Errors display when password reset token is blank");
        HomePage homePage = new HomePage();
        homePage.open();
        ForgotPassWordPage forgotPassWordPage = homePage.gotoLoginPage().goToForgotPassWordPage();
        forgotPassWordPage.forGotPassWord(Constant.USERNAME02);
        String actualFormMsg = "Example message because of no email service";
        String expectedFormMsg = "The password reset token is incorrect or may be expired. Visit the forgot password page to generate a new one.";
        Assert.assertEquals(actualFormMsg, expectedFormMsg, "Form error message is not displayed as expected");
    }

    @Test
    public void TC13() {
        System.out.println("TC13 - Errors display if password and confirm password don't match when resetting password");
        HomePage homePage = new HomePage();
        homePage.open();
        ForgotPassWordPage forgotPassWordPage = homePage.gotoLoginPage().goToForgotPassWordPage();
        forgotPassWordPage.forGotPassWord(Constant.USERNAME02);
        String actualFormMsg = "Example message because of no email service";
        String expectedFormMsg = "The password reset token is incorrect or may be expired. Visit the forgot password page to generate a new one.";
        Assert.assertEquals(actualFormMsg, expectedFormMsg, "Form error message is not displayed as expected");
    }
}

