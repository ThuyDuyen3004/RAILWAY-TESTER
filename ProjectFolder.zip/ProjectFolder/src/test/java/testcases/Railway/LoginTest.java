package testcases.Railway;

import org.testng.Assert;

import common.Constant;
import org.testng.annotations.Test;
import pageObjects.Railway.HomePage;
import pageObjects.Railway.LoginPage;


public class LoginTest extends BaseTest {
    @Test
    public void TC1() {
        System.out.println("TC1 - User can log into Railway with valid username and password");
        HomePage homePage = new HomePage();
        homePage.open();

        LoginPage loginPage = homePage.gotoLoginPage();

        boolean check = loginPage.login(Constant.USERNAME01_Active, Constant.PASSWORD01).checkTabLogoutDisplay();

        Assert.assertTrue(check, "The Logout button is not display as expected");
    }

    @Test
    public void TC2() {
        System.out.println("TC2 - User can't login with blank \"Username\" textbox");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login("", Constant.PASSWORDTC2);
        String actualMsg = loginPage.getErrorMsg();
        String expectedMsg = "There was a problem with your login and/or errors exist in your form.";
        Assert.assertEquals(actualMsg, expectedMsg, "There was a problem with your login and/or errors exist in your form.");
    }

    @Test
    public void TC3() {
        System.out.println("TC3 - User cannot log into Railway with invalid password ");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login(Constant.USERNAMETC3_Deactive, Constant.PASSWORDTC3);
        String actualMsg = loginPage.getErrorMsg();
        String expectedMsg = "There was a problem with your login and/or errors exist in your form.";
        Assert.assertEquals(actualMsg, expectedMsg, "There was a problem with your login and/or errors exist in your form.");
    }

    @Test
    public void TC4() {
        System.out.println("TC4 - Login page displays when un-logged User clicks on \"Book ticket\" tab");
        HomePage homePage = new HomePage();
        homePage.open();
        homePage.gotoBookTicketPage();
        String currentUrl = Constant.WEBDRIVER.getCurrentUrl();
        String expectedUrl = "http://railwayb1.somee.com/Account/Login.cshtml?ReturnUrl=/Page/BookTicketPage.cshtml";
        Assert.assertEquals(currentUrl, expectedUrl, "There was not display correct screen");
    }

    @Test
    public void TC5() {
        System.out.println("TC5 - User cannot log into Railway with invalid password ");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        for (int i = 0; i < 5; i++) {
            loginPage.login(Constant.USERNAMETC3_Deactive, Constant.PASSWORDTC3);
        }
        String actualMsg = loginPage.getErrorMsg();
        String expectedMsg = "You have used 4 out of 5 login attempts. After all 5 have been used, you will be unable to login for 15 minutes.";
        Assert.assertEquals(actualMsg, expectedMsg, "There was a problem with your login and/or errors exist in your form.");
    }

    @Test
    public void TC6() {
        System.out.println("TC6 - Additional pages display once user logged in");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login(Constant.USERNAME01_Active, Constant.PASSWORD01);
        loginPage.gotoMyTicketPage();
        String currentUrl1 = Constant.WEBDRIVER.getCurrentUrl();
        String expectedUrl1 = "http://railwayb1.somee.com/Page/ManageTicket.cshtml";
        Assert.assertEquals(currentUrl1, expectedUrl1, "There was not display correct screen");
        loginPage.gotoChangePasswordPage();
        String currentUrl2 = Constant.WEBDRIVER.getCurrentUrl();
        String expectedUrl2 = "http://railwayb1.somee.com/Account/ChangePassword.cshtml";
        Assert.assertEquals(currentUrl2, expectedUrl2, "There was not display correct screen");
    }

    @Test
    public void TC8() throws InterruptedException {
        System.out.println("TC8 - User can't login with an account hasn't been activated");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login(Constant.USERNAMETC3_Deactive, Constant.PASSWORDTC3);
        Thread.sleep(2000);
        String actualMsg = loginPage.getErrorMsg();
        String expectedMsg = "Invalid username or password. Please try again.";
        Assert.assertEquals(actualMsg, expectedMsg, "errors exist in your form.");

    }
}
