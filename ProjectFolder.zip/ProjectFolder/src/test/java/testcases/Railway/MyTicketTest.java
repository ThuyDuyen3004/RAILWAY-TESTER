package testcases.Railway;

import common.Constant;
import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.Railway.HomePage;
import pageObjects.Railway.LoginPage;
import pageObjects.Railway.MyTicketPage;

public class MyTicketTest extends BaseTest {
    @Test
    public void TC16() throws InterruptedException {
        System.out.println("TC16 - User can cancel a ticket");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login(Constant.USERNAME01_Active, Constant.PASSWORD01);
        MyTicketPage myTicketPage = homePage.gotoMyTicketPage();
        myTicketPage.clickCancelBtn();
        boolean isCanceled = myTicketPage.isTicketCanceledDisplayed();
        if (isCanceled) {
            System.out.println("The button Cancel is display.");
        } else {
            System.out.println("The button Cancel is NOT display.");
        }
        Assert.assertFalse(isCanceled, "The ticket can not cancel.");
    }
}
