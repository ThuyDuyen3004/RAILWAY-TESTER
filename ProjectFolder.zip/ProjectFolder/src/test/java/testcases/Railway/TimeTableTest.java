package testcases.Railway;

import common.Constant;
import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.Railway.*;

public class TimeTableTest extends BaseTest {
    @Test
    public void TC15() {
        System.out.println("TC15 - User can open \"Book ticket\" page by clicking on \"Book ticket\" link in \"Train timetable\" page");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login(Constant.USERNAME01_Active, Constant.PASSWORD01);
        TimeTablePage timeTablePage = homePage.gotoTimeTable();
        BookTicketPage bookTicketPage = timeTablePage.ChoseTicket();
        String departActual = bookTicketPage.getDepartSelected();
        String arriveActual = bookTicketPage.getArriveSelected();
        Assert.assertEquals(departActual, "Huế", "There was a problem with depart location");
        Assert.assertEquals(arriveActual, "Sài Gòn", "There was a problem with arrive location");
    }
}
